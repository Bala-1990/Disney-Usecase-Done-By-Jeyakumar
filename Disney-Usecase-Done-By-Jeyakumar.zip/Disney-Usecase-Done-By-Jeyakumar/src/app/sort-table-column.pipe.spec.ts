import { SortTableColumnPipe } from './sort-table-column.pipe';

describe('SortTableColumnPipe', () => {
  it('create an instance', () => {
    const pipe = new SortTableColumnPipe();
    expect(pipe).toBeTruthy();
  });
});
